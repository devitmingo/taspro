"use client";

import { useState } from "react";
import { Star, Shield, CheckCircle } from "lucide-react";
import Image from "next/image";
import { BookingFlow } from "./booking-flow/BookingFlow";

interface ServiceSummaryCardProps {
  rating: number;
  reviews: number;
  price: number;
  duration: string;
  warranty: string;
  service?: any;
}

export const ServiceSummaryCard: React.FC<ServiceSummaryCardProps> = ({
  rating,
  reviews,
  price,
  duration,
  warranty,
  service,
}) => {
  const [showBookingFlow, setShowBookingFlow] = useState(false);

  return (
    <>
      <div className="bg-white rounded-xl shadow-md p-6 sticky top-6">
        <div className="mb-6">
          <div className="flex items-center gap-1 mb-2">
            <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
            <span className="text-2xl font-bold text-gray-900">{rating}</span>
            <span className="text-gray-600">({reviews} reviews)</span>
          </div>
        </div>

        <div className="border-t border-gray-200 py-4 mb-4">
          <p className="text-gray-600 text-sm mb-1">Price</p>
          <p className="text-3xl font-bold text-gray-900">₹{price}</p>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-gray-700">
            <CheckCircle className="w-5 h-5 text-orange-500" />
            <span className="text-sm">{duration} Duration</span>
          </div>

          <div className="flex items-center gap-3 text-gray-700">
            <Shield className="w-5 h-5 text-orange-500" />
            <span className="text-sm">{warranty} Warranty</span>
          </div>

          <div className="flex items-center gap-3 text-gray-700">
            <CheckCircle className="w-5 h-5 text-orange-500" />
            <span className="text-sm">No Hidden Charges</span>
          </div>
        </div>

        <button
          onClick={() => setShowBookingFlow(true)}
          style={{ backgroundColor: "#FF6B00" }}
          className="w-full text-white font-bold py-3 rounded-lg hover:opacity-90 transition-opacity"
        >
          Book Now
        </button>
      </div>

      {/* Booking Flow Modal */}
      <BookingFlow
        isOpen={showBookingFlow}
        onClose={() => setShowBookingFlow(false)}
        service={service}
        onSuccess={() => {
          // Handle success callback
          console.log("Service booked successfully");
        }}
      />
    </>
  );
};
