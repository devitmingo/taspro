"use client";

import { Star, Clock } from "lucide-react";
import Image from "next/image";

interface ServiceCardProps {
  title: string;
  image: string;
  rating: number;
  reviewCount: number;
  price: number;
  originalPrice: number;
  duration: string;
  onBook: () => void;
}

const ServiceCard = ({
  title,
  image,
  rating,
  reviewCount,
  price,
  originalPrice,
  duration,
  onBook,
}: ServiceCardProps) => {
  return (
    <div 
      className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden flex-shrink-0 snap-center group flex flex-col"
      style={{
        width: '287px',
        height: '220px',
        borderRadius: '16px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.08)'
      }}
    >
      <div 
        className="relative w-full overflow-hidden"
        style={{
          height: '135px',
          borderTopLeftRadius: '16px',
          borderTopRightRadius: '16px',
        }}
      >
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          style={{ objectFit: 'cover' }}
        />
      </div>
      <div className="p-3 flex flex-col justify-between flex-grow" style={{ padding: '12px 16px' }}>
        <div>
          <h3 className="font-bold text-gray-900 mb-1 truncate" style={{ fontSize: '14px', lineHeight: '1.2' }}>{title}</h3>
          
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center bg-green-50 px-1.5 py-0.5 rounded-md border border-green-100">
              <Star className="w-3 h-3 text-green-600 fill-current" />
              <span className="text-xs font-bold text-green-700 ml-1">{rating}</span>
            </div>
            <span className="text-xs text-gray-500">({reviewCount.toLocaleString()})</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-gray-900">₹{price}</span>
              <span className="text-xs text-gray-400 line-through">₹{originalPrice}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
              <Clock className="w-3 h-3" />
              <span>{duration}</span>
            </div>
          </div>
          <button 
            onClick={onBook}
            className="px-3 py-1.5 bg-orange-500 text-white text-xs font-semibold rounded-lg hover:bg-orange-600 transition-colors shadow-sm hover:shadow-md"
            style={{
              height: '32px',
              padding: '0 12px',
              borderRadius: '6px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;