"use client";

import Image from "next/image";
import Link from "next/link";

interface Service {
  id: string;
  name: string;
  image: string;
}

const HeroSection = () => {
  const heroServices: Service[] = [
    { id: 'ac-appliance-repair', name: 'AC & Appliance Repair', image: '/hero1.png' },
    { id: 'deep-cleaning', name: 'Deep Cleaning Services', image: '/hero2.png' },
    { id: 'handyman', name: 'Handyman Services', image: '/hero3.png' },
    { id: 'pest-control', name: 'Pest Control & Waterproofing', image: '/hero4.png' },
    { id: 'cleaning-packages', name: 'Cleaning Packages', image: '/hero5.png' },
    { id: 'amc-service', name: 'AMC Service Plan', image: '/hero6.png' }
  ];

  return (
    <section className="bg-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1260px] mx-auto">
        {/* Two Column Layout */}
        <div className="flex flex-col lg:flex-row items-start justify-between gap-[48px]">
          
          {/* Left Side Content */}
          <div className="w-full lg:flex-[0.7] flex flex-col justify-center">
            <h1 
              className="text-[28px] leading-[42px] font-semibold tracking-[-0.3px] text-gray-900 mb-8 text-left"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              How can we serve you today?
            </h1>
            
            {/* Service Cards - 2 rows, 3 cards per row */}
            <div className="w-full grid grid-cols-3 gap-4"
                 style={{
                   gap: '16px'
                 }}>
              {heroServices.map((service) => (
                <Link
                  key={service.id}
                  href={`/services/${service.id}`}
                  className="group flex flex-col items-center bg-blue-50/30 rounded-[16px] hover:scale-[1.03] hover:shadow-xl transition-all duration-300 ease-out justify-center"
                  style={{ 
                    padding: '24px',
                    minHeight: '160px'
                  }}
                >
                  <div className="w-12 h-12 mb-4 flex items-center justify-center flex-shrink-0">
                    <Image
                      src={service.image}
                      alt={service.name}
                      width={48}
                      height={48}
                      className="object-contain"
                    />
                  </div>
                  <h3 className="text-sm font-medium text-gray-900 text-center group-hover:text-blue-600 transition-colors duration-300 leading-tight line-clamp-2">
                    {service.name}
                  </h3>
                </Link>
              ))}
            </div>
          </div>
          
          {/* Right Side Image */}
          <div className="w-full lg:flex-[0.4] h-[472px] flex-shrink-0">
            <div className="relative w-full h-full rounded-[24px] overflow-hidden">
              <Image
                src="/heroimage.jpg"
                alt="Hero"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 500px"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;