"use client";

import { ChevronRight, ChevronLeft, Wrench, Zap, Flame, Droplets, WashingMachine, Fan, Refrigerator, Microwave, Droplet, Tv, Monitor, MoreHorizontal } from "lucide-react";
import { SERVICES_DATA } from "@/data/services";

const appliances = [
  { slug: "ac-repair", icon: Wrench, label: "AC Repair", color: "from-blue-500 to-blue-600" },
  { slug: "geyser-repair", icon: Droplets, label: "Geyser Repair", color: "from-orange-500 to-orange-600" },
  { slug: "gas-stove-repair", icon: Flame, label: "Gas Stove Repair", color: "from-red-500 to-red-600" },
  { slug: "water-cooler-repair", icon: Droplet, label: "Water Cooler Repair", color: "from-cyan-500 to-cyan-600" },
  { slug: "washing-machine-repair", icon: WashingMachine, label: "Washing Machine Repair", color: "from-purple-500 to-purple-600" },
  { slug: "kitchen-chimney-repair", icon: Fan, label: "Kitchen Chimney Repair", color: "from-gray-500 to-gray-600" },
  { slug: "refrigerator-repair", icon: Refrigerator, label: "Refrigerator Repair", color: "from-indigo-500 to-indigo-600" },
  { slug: "microwave-repair", icon: Microwave, label: "Microwave Repair", color: "from-pink-500 to-pink-600" },
  { slug: "water-purifier-repair", icon: Droplet, label: "Water Purifier Repair", color: "from-teal-500 to-teal-600" },
  { slug: "tv-repair", icon: Tv, label: "TV Repair", color: "from-amber-500 to-amber-600" },
  { slug: "computer-repair", icon: Monitor, label: "Computer Repair", color: "from-emerald-500 to-emerald-600" },
  { icon: MoreHorizontal, label: "See All Services", color: "from-gray-600 to-gray-700" },
];

const ApplianceRepair = () => {
  return (
    <section className="py-16 bg-background">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Expert
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-600"> Appliance Repair</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional repair services for all major home appliances with guaranteed quality work
          </p>
        </div>

        <div className="relative">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {appliances.map((appliance, index) => (
              <a
                key={index}
                href={appliance.slug ? `/service/${appliance.slug}` : "/services"}
                className="flex flex-col items-center p-6 rounded-2xl bg-card shadow-card border border-border hover:border-primary transition-all duration-300 group"
              >
                <div className={`w-[118px] h-[82px] rounded-xl bg-gradient-to-br ${appliance.color} flex items-center justify-center group-hover:scale-110 transition-transform shadow-md mx-auto`}>
                  <appliance.icon className="w-12 h-6 text-white" style={{ opacity: 1, transform: 'rotate(0deg)' }} />
                </div>
                <span className="text-sm text-center text-foreground font-semibold leading-tight group-hover:text-primary transition-colors mt-4">
                  {appliance.label}
                </span>
              </a>
            ))}
          </div>

          {/* Navigation Arrows */}
          <button className="absolute -left-6 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-card shadow-card flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all duration-300 border border-border hidden lg:flex">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button className="absolute -right-6 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-primary text-primary-foreground shadow-card flex items-center justify-center hover:bg-primary/90 transition-all duration-300 hidden lg:flex">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-8 bg-muted rounded-2xl p-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">24/7</div>
              <div className="text-sm text-muted-foreground">Emergency Service</div>
            </div>
            <div className="h-12 w-px bg-border"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">98%</div>
              <div className="text-sm text-muted-foreground">Customer Satisfaction</div>
            </div>
            <div className="h-12 w-px bg-border"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">5000+</div>
              <div className="text-sm text-muted-foreground">Repairs Completed</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ApplianceRepair;
